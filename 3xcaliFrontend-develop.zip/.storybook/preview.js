import { addDecorator } from '@storybook/react';
import { ThemeContextProvider } from '../src/theme/theme-context';
import { themes } from '@storybook/theming';

export const parameters = {
  actions: { argTypesRegex: "^on[A-Z].*" },
  controls: {
    matchers: {
      color: /(background|color)$/i,
      date: /Date$/,
    },
  },
  darkMode: {
    // Override the default dark theme
    dark: { ...themes.dark, appBg: 'black' },
    // Override the default light theme
    light: { ...themes.normal, appBg: 'white' }
  },
  design: {
     type: 'figma',
     url: `${process.env.FIGMA_URL}`
  }
}

addDecorator((story) => (
  <ThemeContextProvider>{story()}</ThemeContextProvider>
));