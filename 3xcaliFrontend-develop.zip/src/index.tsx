import ReactDOM from "react-dom";
import store from "./store/store";
import { Provider } from "react-redux";
import { Web3ContextProvider } from "./hooks";
import React from "react";
import App from "./Root/App";

ReactDOM.render(
        <Provider store={store}>
            <Web3ContextProvider>
                <App/>
            </Web3ContextProvider>
        </Provider>,
    document.getElementById("root"),
);
