export const TOKEN_DECIMALS = 9;

export enum Networks {
    AVAX = 43114,
}

export const DEFAULD_NETWORK = Networks.AVAX;
