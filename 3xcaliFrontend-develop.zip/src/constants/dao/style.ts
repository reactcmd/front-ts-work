export const DRAWER_WIDTH = 280;
export const TRANSITION_DURATION = 969;
