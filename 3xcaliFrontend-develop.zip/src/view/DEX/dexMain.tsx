function DEXMain() {

    return (
        <div>
            DEX PAGE!
        </div>
    );
}

export default DEXMain;
