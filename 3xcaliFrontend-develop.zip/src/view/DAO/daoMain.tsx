function DAOMain() {

    return (
        <div>
            DAO PAGE!
        </div>
    );
}

export default DAOMain;
