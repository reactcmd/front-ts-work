import { Switch,Route,BrowserRouter as Router } from "react-router-dom";
import ConnectMenu from "src/components/Header/connect-button";
import DAOMain from "src/view/DAO/daoMain";
import DEXMain from "src/view/DEX/dexMain";
import ProgressBar from "../stories/ProgressBar/ProgressBar"
import { Avatar } from "../stories/Avatar/Avatar"
function App() {

    return (
        <div>
            <ConnectMenu></ConnectMenu>
            <Router>
                <Switch>
                    <Route path="/dao">
                        <DAOMain />
                        <Avatar />
                        <ProgressBar/>
                    </Route>

                    <Route path="/dex">
                        <DEXMain />
                    </Route>

                </Switch>
            </Router>
        </div>
    );
}

export default App;
