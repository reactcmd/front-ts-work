import { RocketLaunch } from '@mui/icons-material';
import React from 'react';
import { Icon } from '../Icon/Icon';
import LaunchOutlinedIcon from '@mui/icons-material/LaunchOutlined';
import ArrowForwardOutlinedIcon from '@mui/icons-material/ArrowForwardOutlined';
import { Button } from './Button';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: '3six9/Button',
  component: Button,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {
    backgroundColor: { control: 'color' },
  },
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template:any = (args:Record<string,any>) =><Button {...args} />;

export const PrimaryButton = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
PrimaryButton.args = {
  label: 'Button',
  icons:{startIcon:RocketLaunch}
};

export const SecondaryButton = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
SecondaryButton.args = {
  label: 'Button',
  icons:{startIcon:RocketLaunch},
  buttonType:"defaultSecondary"
};

export const UnstyledButton = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
UnstyledButton.args = {
  label: 'Button',
  icons:{startIcon:RocketLaunch},
  buttonType:"unstyled"
};

export const FullSizeButtonExample = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
FullSizeButtonExample.args = {
  label: 'Button',
  icons:{startIcon:RocketLaunch,edgeIcon:<Icon Children={ArrowForwardOutlinedIcon} size={"md"}></Icon>},
  fullWidth:true
};
export const OnlyIconButton = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
OnlyIconButton.args = {
  icons:{startIcon:RocketLaunch},
  iconSize:"md"
};
export const LinkButton = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
LinkButton.args = {
  label: 'Link Label ',
  icons:{endIcon:LaunchOutlinedIcon},
  iconSize:"md",
  buttonType:"unstyled"
};