import { Grid } from '@mui/material';
import { styled } from '@mui/system';
import { useThemeContext } from '../../../theme/theme-context';

export const ButtonLayouts = ({gridItems,spacing,...props}:any) => {

  const { theme } = useThemeContext()

  const CustomGrid:any = styled(Grid)(()=>({}))

  return (
    <CustomGrid 
    container
    direction={"row"}
    justify={"flex-start"}
    alignItems={"center"}
    spacing={theme.spacing(spacing)}
    >
      {
        gridItems.map((val:any,index:any)=>{
          return <Grid key={index} item xs={val.size}>{val.button}</Grid>
        })
      }
    </CustomGrid>
  
  );
};

ButtonLayouts.propTypes = {
};

ButtonLayouts.defaultProps = {
  spacing:2
};