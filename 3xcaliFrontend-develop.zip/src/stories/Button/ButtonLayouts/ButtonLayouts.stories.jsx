import { ArrowForwardOutlined, RocketLaunch } from '@mui/icons-material';
import React from 'react';
import { Icon } from '../../Icon/Icon';
import { Button } from '../Button';
import { FullSizeButtonExample } from '../Button.stories';
import { ButtonLayouts } from './ButtonLayouts';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: '3six9/Button/ButtonLayouts',
  component: ButtonLayouts,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {
    backgroundColor: { control: 'color' },
  },
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template = (args) => <ButtonLayouts {...args} />;

export const ButtonLayout2plus1 = Template.bind({});
ButtonLayout2plus1.args = {
    gridItems:[
        {size:6,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:6,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:12,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
    ]
};

export const ButtonLayout3x2 = Template.bind({});
ButtonLayout3x2.args = {
    gridItems:[
        {size:4,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:4,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:4,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:4,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:4,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:4,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
    ]
};

export const ButtonLayout1x3 = Template.bind({});
ButtonLayout1x3.args = {
    gridItems:[
        {size:12,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:12,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:12,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>}
    ]
};

export const ButtonLayout2x2 = Template.bind({});
ButtonLayout2x2.args = {
    gridItems:[
        {size:6,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:6,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:6,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:6,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>}
    ]
};

export const ButtonLayout1x2 = Template.bind({});
ButtonLayout1x2.args = {
    gridItems:[
        {size:12,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:12,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
    ]
};

export const ButtonLayout3x1 = Template.bind({});
ButtonLayout3x1.args = {
    gridItems:[
        {size:4,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:4,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:4,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>}
    ]
};

export const ButtonLayout2x1 = Template.bind({});
ButtonLayout2x1.args = {
    gridItems:[
        {size:6,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>},
        {size:6,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>}
    ]
};

export const ButtonLayout1x1 = Template.bind({});
ButtonLayout1x1.args = {
    gridItems:[
        {size:12,button:
        <Button 
            label={'Button'}
            icons={{}}
            fullWidth={true}>
        </Button>}
    ]
};