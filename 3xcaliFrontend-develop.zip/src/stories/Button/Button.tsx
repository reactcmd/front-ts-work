import React from 'react';
import PropTypes from 'prop-types';
import { Button as BTN,styled } from '@mui/material';
import { useThemeContext } from '../../theme/theme-context';
import { Label } from '../label/Label';
import { returnButtonVariants } from '../Helpers';
import { icon } from '../../theme/theme-constants/avatar-icon-constants';

export const Button:any = ({ size,label,buttonType,icons,buttonOrientation,fullWidth,onClick,colorOverride, ...props }:any) => {

  const { theme } = useThemeContext()

  const buttonPalette:any = returnButtonVariants(buttonType,theme)

  const BaseButton = styled(BTN)(() => ({
      backgroundColor: buttonPalette.backgroundColor,
      border:`thin ${buttonPalette.borderColor} solid`,
      "& svg":{
        color:colorOverride!==null?colorOverride:buttonPalette.color,
      },
      "& p":{
        color:colorOverride!==null?colorOverride:buttonPalette.color,
        fontWeight:buttonPalette.fontWeight,
        fontSize:buttonPalette.fontSize,
      },
      "&:hover svg":{
        color:buttonPalette.contrastText
      },
      "&:hover p":{
        color:buttonPalette.contrastText
      },
      "&:hover":{
        backgroundColor:buttonPalette.hoverBg,
      },
      "&:active":{
        backgroundColor:buttonPalette.activeBg,
      },
      "&:active svg":{
        color:buttonPalette.activeColor
      },
      "&:active p":{
        color:buttonPalette.activeColor
      },
      display:"flex",
      flexDirection:"row",
      justifyContent:returnIconChild('edgeIcon')?"space-between":buttonOrientation
  }))

  const returnIconButtonSize = () =>{
    return icon["md"]+8 //assuming 8px padding from the figma file (STORE THESE AS CONSTANTS LATER)
  }

  const checkIfIconButton = () =>{
    return (returnIconChild('startIcon')&&!label)?{maxWidth: returnIconButtonSize(), maxHeight: returnIconButtonSize(), minWidth: returnIconButtonSize(), minHeight: returnIconButtonSize(),padding:theme.spacing(2)}:{}
  }

  const returnIconChild = (iconType:any) =>{
    console.log(icons)
    return icons[iconType]!==null?icons[iconType]:null
  }

  return (
    <BaseButton
    size={size}
    style={{textTransform: 'none',...checkIfIconButton()}}
    disableRipple={true}
    disableElevation={true}
    fullWidth={fullWidth}
    endIcon={returnIconChild('edgeIcon')}
    onClick={()=>onClick()}
    >
        <Label spacing={2}starticon={returnIconChild('startIcon')} iconSize={"lg"} label={label} endicon={returnIconChild('endIcon')}></Label>
    </BaseButton>
  );
};

Button.propTypes = {
  label:  PropTypes.string,
  size:PropTypes.oneOf(["small","medium","large"]),
  buttonType:PropTypes.oneOf(["default","defaultSecondary","unstyled"]),
  buttonOrientation:PropTypes.oneOf(["flex-start","flex-end","center","space-between"]),
  fullWidth:PropTypes.bool
};

Button.defaultProps = {
  buttonType:"default",
  size:"medium",
  buttonOrientation:"center",
  fullWidth:false,
  onClick:()=>{},
  colorOverride:null
};