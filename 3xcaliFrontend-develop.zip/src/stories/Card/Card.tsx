import React from "react";
import Card from "@mui/material/Card";
import CardActionArea from "@mui/material/CardActionArea";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import { Button } from '../Button/Button';
import { Label } from '../label/Label'
import LinearProgress from '@mui/material/LinearProgress';
import Box from '@mui/material/Box';
import { Avatar } from '../Avatar/Avatar';
import { useThemeContext } from '../../theme/theme-context';
import PropTypes from 'prop-types';
import ProgressBar from "../ProgressBar/ProgressBar";
import { avatar } from '../../theme/theme-constants/avatar-icon-constants';
import { styled } from '@mui/system';



export const CustomCard:any = ({summary,
  startIcon,endIcon,iconSize,label,variant,spacing, width,size ,...props }:any) => {
  
  
  const { theme } = useThemeContext()

  const CustomProgressBar:any = styled(ProgressBar)(()=>({}))

  return (
    <Card sx={{ backgroundColor:theme.palette.primary.main,width:width}}>
      
      <CardActionArea>
          <CardMedia>
              <Avatar  align="center" sx= {{width: `${avatar[size]}px`,height: `${avatar[size]}px` }} alt="Remy Sharp" src="" />
          </CardMedia>
      <CardContent>
      <Label  align="center" label={label} variant={"h3"} />
        <Label align="center" label={label} variant={"body1"} />
          <Box>
            <CustomProgressBar sx={{marginTop: "200 px"}}/>
          </Box>


          <Button
                styles={{backgroundColor: theme.palette.primary.dark,}}
                label={"buttonLabel"}
                icons={{}}
                fullWidth={true}
               
                />
  
          
                
  

        </CardContent>
      </CardActionArea>
      <CardActions>
        
      </CardActions>
    </Card>
  );
}

CustomCard.propTypes = {
  summary:PropTypes.string,
  iconSize:PropTypes.string,
  size:'xl',
};
