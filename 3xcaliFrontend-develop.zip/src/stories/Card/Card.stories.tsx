import React from "react";

import { CustomCard } from "./Card";

export default {
  title: "3six9/Card",
  component: CustomCard,
};
const Template:any = (args:Record<string,any>) =><CustomCard {...args} />;
export const CardComponent = Template.bind({});
CardComponent.args = {
  summary:
    "body text for Accordions",
  label: "Label Text",
  iconSize:"sm",
  width: "50%",
};