import React from "react";
import CircleIcon from '@mui/icons-material/Circle';

import { CustomAccordion }  from "./Accordion";

export default {
  title: "3six9/Accordion",
  component: CustomAccordion,
  argTypes: {
    backgroundColor: { control: 'color' },
  },
};

const Template:any = (args:Record<string,any>) => <CustomAccordion {...args} />;
export const SimpleAccordion = Template.bind({});
SimpleAccordion.args = {
  summary:
    "body text for Accordions",
  iconSize:"sm",
  icons:{ startIcon: CircleIcon , expandIcon: CircleIcon  }
  
};