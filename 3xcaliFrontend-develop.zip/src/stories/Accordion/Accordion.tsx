import React from "react";
import { styled } from "@mui/material";
import {Accordion as ACD} from '@mui/material/';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import CircleIcon from '@mui/icons-material/Circle';
import { Button } from '../Button/Button';
import { Icon } from '../Icon/Icon';
import { useThemeContext } from '../../theme/theme-context';
import { Label } from '../label/Label'
import PropTypes from 'prop-types';

export  const CustomAccordion:any  = ({summary,label,icons, iconSize, ...props}:any) => {
  
  const { theme } = useThemeContext()

  const BaseAccordion = styled(ACD)(() => ({
    backgroundColor: theme.palette.primary.main,
  }))
  
  const returnIconChild = (iconType:any) => {
    return icons[iconType]!==null?icons[iconType]:null
  }

  const CustomAccordionSummary:any = styled(AccordionSummary)(()=>({}))

  return (
    <div style={{backgroundColor: theme.backgroundColor}}>
      <BaseAccordion disableGutters={true}>
        <CustomAccordionSummary  
          spacing={2}
          expandIcon= {<Icon Children={CircleIcon} iconSize={"md"}></Icon>}
          aria-controls="panel1a-content"
          id="panel1a-header"
          {...{}} 
        >
          

          <Label spacing={2} starticon = {returnIconChild('startIcon')} iconSize={"sm"} label={"Accordion 1"} variant={"body1"} 
          endicon={returnIconChild('endIcon')}></Label>


        </CustomAccordionSummary>
        <AccordionDetails>
        <Label spacing={2}  iconSize={"sm"} 
                label={summary} variant={"body1"}>
              </Label>
        </AccordionDetails>
        <Button
                label={"buttonLabel"}
                icons={{}}
                fullWidth={true}
                sx={{backgroundColor: theme.palette.primary.dark}}
                />

            
      </BaseAccordion>



      <BaseAccordion disableGutters={true}>
        <CustomAccordionSummary  
          spacing={2}
          expandIcon= {<Icon Children={CircleIcon} iconSize={"md"}></Icon>}
          aria-controls="panel1a-content"
          id="panel1a-header" 
        >
          

          <Label spacing={2} starticon = {returnIconChild('startIcon')} iconSize={"sm"} label={"Accordion 2"} variant={"body1"} 
          endicon={returnIconChild('endIcon')}></Label>


        </CustomAccordionSummary>
        <AccordionDetails>
            <Label spacing={2}  iconSize={"sm"} 
                label={summary} variant={"body1"}>
              </Label>
        </AccordionDetails>
        <Button
                label={"buttonLabel"}
                icons={{}}
                fullWidth={true}
                sx={{backgroundColor: theme.palette.primary.dark}}
                />


            
      </BaseAccordion>

      

      <BaseAccordion disableGutters={true}>
        <CustomAccordionSummary  spacing={2}
          expandIcon= {<Icon Children={CircleIcon} iconSize={"md"}></Icon>}
          aria-controls="panel1a-content"
          id="panel1a-header" 
        >
          

          <Label spacing={2} starticon = {returnIconChild('startIcon')} iconSize={"sm"} label={"Accordion 3"} variant={"body1"} 
          endicon={returnIconChild('endIcon')}></Label>


        </CustomAccordionSummary>
        <AccordionDetails>
            <Label spacing={2}  iconSize={"sm"} 
                label={summary} variant={"body1"}>
              </Label>
        </AccordionDetails>
        <Button
                label={"buttonLabel"}
                icons={{}}
                fullWidth={true}
                sx={{backgroundColor: theme.palette.primary.dark}}
                />


            
      </BaseAccordion>
    </div>
  );
}


CustomAccordion.propTypes = {
  summary:PropTypes.string,
  label: PropTypes.string,
};
