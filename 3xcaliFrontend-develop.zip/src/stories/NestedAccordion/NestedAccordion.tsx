import React from "react";
import { styled } from "@mui/material";
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import CircleIcon from '@mui/icons-material/Circle';
import {Button} from '../Button/Button';
import {Icon} from '../Icon/Icon';
import { useThemeContext } from '../../theme/theme-context';
import { Label } from '../label/Label'
import PropTypes from 'prop-types';

export const NestedAccordion:any = ({summary,label,icons, iconSize, ...props}:any) => {

  const { theme } = useThemeContext()


  const returnIconChild = (iconType:any) => {
    return icons[iconType]!==null?icons[iconType]:null
  }

  return (
    <div style={{backgroundColor: theme.palette.primary.main}}>
      <Accordion  disableGutters={true} sx={{backgroundColor: theme.palette.primary.main,}}>
        <AccordionSummary 
          expandIcon= {<Icon Children={CircleIcon} iconSize={"md"}></Icon>}
          aria-controls="panel1a-content"
          id="panel1a-header" 
        >

          
          
        <Label spacing={2} starticon = {returnIconChild('startIcon')} iconSize={"sm"} label={"Accordion 1"} variant={"body1"} 
          endicon={returnIconChild('endIcon')}>
        </Label>

        </AccordionSummary>

        <Accordion  disableGutters={true} sx={{backgroundColor: theme.palette.primary.dark,}}>
            <AccordionSummary 
            expandIcon= {<Icon Children={CircleIcon} iconSize={"md"}></Icon>}
            aria-controls="panel1a-content"
            id="panel1a-header" 
            >
            
            <Label spacing={2} starticon = {returnIconChild('startIcon')} iconSize={"sm"} label={"Accordion 1"} variant={"body1"} 
              endicon={returnIconChild('endIcon')}>
            </Label>
            </AccordionSummary>


            <AccordionDetails>
              <Label spacing={2}  iconSize={"sm"} 
                label={summary} variant={"body1"}>
              </Label>
            </AccordionDetails>


            <Button
                label={"buttonLabel"}
                icons={{}}
                fullWidth={true}
                sx={{backgroundColor: theme.palette.primary.main}}
                />


                
        </Accordion>


        <AccordionDetails>
            <Label spacing={2}  iconSize={"sm"} 
                label={summary} variant={"body1"}>
              </Label>
        </AccordionDetails>
        <Button
                label={"buttonLabel"}
                icons={{}}
                fullWidth={true}
                sx={{backgroundColor: theme.palette.primary.main}}
                />


            
      </Accordion>
    </div>
  );
}