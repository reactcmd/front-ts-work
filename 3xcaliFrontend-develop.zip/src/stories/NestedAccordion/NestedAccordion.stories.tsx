import React from "react";
import CircleIcon from '@mui/icons-material/Circle';

import { NestedAccordion }  from "./NestedAccordion";

export default {
  title: "3six9/Accordion/NestedAccordion",
  component: NestedAccordion,
  argTypes: {
    backgroundColor: { control: 'color' },
  },
};


const Template:any = (args:any) => <NestedAccordion {...args} />;

export const CustomNestedAccordionComponent = Template.bind({});
  CustomNestedAccordionComponent.args = {
    summary:
        "body text for Accordions",
      iconSize:"sm",
      icons:{ startIcon: CircleIcon , expandIcon: CircleIcon  }
  
};