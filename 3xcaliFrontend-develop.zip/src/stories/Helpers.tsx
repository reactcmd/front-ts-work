export const returnButtonVariants = (type:any,theme:any) =>{
  switch(type){
    case "default":{
      return {
        backgroundColor:theme.palette.primary.main,
        color:theme.palette.text.button,
        fontWeight:theme.typography.button.fontWeight,
        fontSize:theme.typography["button"].fontSize,
        contrastText:theme.palette.primary.contrastText,
        hoverBg:theme.palette.primary["800"],
        activeBg:theme.palette.primary["700"],
        borderColor:"transparent",
        activeColor:theme.palette.primary.contrastText
      }
    }
    case "defaultSecondary":{
      return {
        backgroundColor:"transparent",
        color:theme.palette.secondary["20"],
        fontWeight:theme.typography.button.fontWeight,
        fontSize:theme.typography.button.fontSize,
        contrastText:theme.palette.secondary["700"],
        hoverBg:theme.palette.secondary["20"],
        activeBg:theme.palette.secondary["100"],
        borderColor:theme.palette.secondary["100"],
        activeColor:theme.palette.primary.contrastText
      }
    }
    case "unstyled":{
      return {
        backgroundColor:"transparent",
        color:theme.palette.primary.contrastText,
        fontWeight:theme.typography.button.fontWeight,
        fontSize:theme.typography.button.fontSize,
        contrastText:theme.palette.primary["70"],
        hoverBg:"transparent",
        activeBg:"transparent",
        borderColor:"transparent",
        activeColor:theme.palette.secondary["100"]
      }
    }
  }
}

export const dropDownVariants = (type:any,theme:any) =>{
  switch(type){
    case "default":{
      return {
        backgroundColor:theme.palette.primary["700"],
        itemBg:theme.palette.primary["90"],
        color:theme.palette.primary.contrastText
      }
    }
  }
}

export const inputVariants = (type:any,theme:any) =>{
  switch(type){
    case "default":{
      return {
        borderColorNormal:theme.palette.primary["70"],
        textColorNormal:theme.palette.primary["70"],
        textColorOther:theme.palette.primary.contrastText,
        borderColorSelected:theme.palette.primary.contrastText,
        borderColorError:theme.palette.error.main,
        backgroundColor:theme.palette.primary["900"]
      }
    }
  }
}