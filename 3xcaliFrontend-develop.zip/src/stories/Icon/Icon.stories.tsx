import React from 'react';

import { Icon } from './Icon';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: '3six9/Icon',
  component: Icon,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {
    backgroundColor: { control: 'color' },
  },
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template:any = (args:Record<string,any>) =><Icon {...args} />;

export const IconXS = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
IconXS.args = {
    size:"xs"
};

export const IconS = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
IconS.args = {
    size:"sm",
};

export const IconM = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
IconM.args = {
    size:"md"
};

export const IconL = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
IconL.args = {
    size:"lg"
};

export const IconXL = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
IconXL.args = {
    size:"xl"
};

export const IconXXL = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
IconXXL.args = {
    size:"xxl"
};

export const Icon3XL = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Icon3XL.args = {
    size:"3xl"
};

export const Icon4XL = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Icon4XL.args = {
    size:"4xl"
};

export const Icon5XL = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Icon5XL.args = {
    size:"5xl"
};

export const Icon7XL = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Icon7XL.args = {
    size:"7xl"
};

