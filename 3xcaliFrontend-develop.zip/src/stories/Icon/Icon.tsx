import React from 'react';
import PropTypes from 'prop-types';
import { Avatar as UserAvatar } from '@mui/material';
import { icon } from '../../theme/theme-constants/avatar-icon-constants';
import { styled } from '@mui/system';
import { RocketLaunch } from '@mui/icons-material';
import { useThemeContext } from '../../theme/theme-context';

export const Icon:any = ({ size,image,alt,Children,iconColor, ...props }:any) => {

  const { theme } = useThemeContext()

  const MuiIcon = styled(Children!==null?Children:"div")(() => ({
      width:icon[size],
      height:icon[size],
      color:iconColor!==null?iconColor:theme.palette.text.typography
  }))

  return (
    <UserAvatar sx={{ width: `${icon[size]}px`, height: `${icon[size]}px`,backgroundColor:"transparent" }} variant="square" alt={alt}>
        {
                <MuiIcon></MuiIcon>
        }
    </UserAvatar>
  );
};

Icon.propTypes = {
    size:PropTypes.string,
    image:PropTypes.any,
    alt:PropTypes.string,
    Children:PropTypes.any
};

Icon.defaultProps = {
    size:'sm',
    image:"",
    alt:"",
    Children:RocketLaunch
};