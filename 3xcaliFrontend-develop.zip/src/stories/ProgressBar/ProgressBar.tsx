import * as React from 'react';
import Box from '@mui/material/Box';
import LinearProgress from '@mui/material/LinearProgress';
import { styled } from '@mui/system';

export default function ProgressBar() {

  const CustomBox:any = styled(Box)(()=>({}))

  return (
      <CustomBox fullWidth={true}>
        <LinearProgress variant="determinate" value={35} sx={{padding: "3px" , borderRadius: "1000px"}}/>
      </CustomBox>
    )
  }
