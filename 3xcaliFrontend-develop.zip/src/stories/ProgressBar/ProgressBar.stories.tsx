import React from "react";

import ProgressBar from "./ProgressBar";

export default {
  title: "3six9/ProgressBar",
  component: ProgressBar,
};
const Template:any = (args:any) => <ProgressBar {...args} />;
export const LinearProgressBar = Template.bind({});
LinearProgressBar.args = {};