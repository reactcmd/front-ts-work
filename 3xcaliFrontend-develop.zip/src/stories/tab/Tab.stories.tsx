import { RocketLaunch } from '@mui/icons-material';
import React from 'react';
import { Label } from '../label/Label';

import { TabHeader } from './TabHeader';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: '3six9/Tabs',
  component: TabHeader,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {
    backgroundColor: { control: 'color' },
  },
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template:any = (args:any) => <TabHeader {...args} />;

export const HorizontalTab = Template.bind({});
// More on  args: https://storybook.js.org/docs/react/writing-stories/args
HorizontalTab.args = {
  tabData:[
    <Label label={'Label Test'} starticon={RocketLaunch} variant={"button"}></Label>,
    <Label label={'Label Test'} starticon={RocketLaunch} variant={"button"}></Label>,
    <Label label={'Label Test'} starticon={RocketLaunch} variant={"button"}></Label>,
    <Label label={'Label Test'} starticon={RocketLaunch} variant={"button"}></Label>
  ],
  tabChanged:(index:any)=>{
    console.log(index)
  },
  variant:"standard"
};

//it will look weird in stories, in production we just have to wrap it in a div with width:'fit-content'
export const VerticalTab = Template.bind({});
VerticalTab.args = {
  orientation:"vertical",
  variant:"standard",
  tabData:[
    <Label label={'Label Test'} starticon={RocketLaunch} variant={"button"}></Label>,
    <Label label={'Label Test'} starticon={RocketLaunch} variant={"button"}></Label>,
    <Label label={'Label Test'} starticon={RocketLaunch} variant={"button"}></Label>,
    <Label label={'Label Test'} starticon={RocketLaunch} variant={"button"}></Label>
  ],
  tabChanged:(index:any)=>{
    console.log(index)
  }
};