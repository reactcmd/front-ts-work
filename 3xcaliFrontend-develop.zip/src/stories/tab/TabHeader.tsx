import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Tabs,Tab as TB } from '@mui/material';
import { styled } from '@mui/system';
import { makeStyles } from '@mui/styles';
import { useThemeContext } from '../../theme/theme-context';

export const TabHeader:any = ({ tabData,orientation,variant,start,tabChanged,fontSize,textColorOnly,fitLabel,...props }:any) => {

  const [currentTab,setCurrentTab] = useState(start)

  const returnTabItem = (index:any) =>{
    setCurrentTab(index)
    tabChanged(index)
  }
  const { theme } = useThemeContext()
  
  const colorToChangeHover =`${textColorOnly?"&:hover p":"&:hover *"}`
  const colorToChange =`${textColorOnly?"& p":"& svg,p"}`

  const TabLabel = styled(TB)(()=>({
    "&.Mui-selected *":{
      color:theme.palette.primary["10"]
    },
    [colorToChangeHover]:{
      color:theme.palette.secondary["100"]
    },
    [colorToChange]:{
      color:theme.palette.primary["30"]
    },
    textTransform:"none",
  }))
  
  const classes = makeStyles({
    indicator: {
      backgroundColor: theme.palette.primary["10"],
    },
  })()

  return (
      <Tabs 
      variant={variant}
      orientation={orientation}
      value={currentTab}
      TabIndicatorProps={orientation==='vertical'?{ style: { left: 0 } }:{}}
      classes={{indicator: classes.indicator}}
      >
          {
              tabData.map((value:any,index:any)=>{
                  return <TabLabel key={index} label={value} onClick={()=>returnTabItem(index)}/>
              })
          }
      </Tabs>
  );
};

TabHeader.propTypes = {
    orientation:PropTypes.string,
    variant:PropTypes.string,
    tabData:PropTypes.any,
    start:PropTypes.number,
    tabChanged:PropTypes.any,
    textColorOnly:PropTypes.bool,
    fitLabel:PropTypes.bool
};

TabHeader.defaultProps = {
    orientation:"horizontal",
    variant:"fullWidth",
    tabData:[],
    start:0,
    textColorOnly:false,
    fitLabel:true,
    tabChanged:()=>{}
};