import { ArrowDownwardSharp, RocketLaunch } from '@mui/icons-material';
import { Typography } from '@mui/material';
import React from 'react';

import { DropDown } from './DropDown';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: '3six9/DropDowns',
  component: DropDown,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {
    backgroundColor: { control: 'color' },
  },
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template:any = (args:Record<string,any>) =><DropDown {...args} />;

export const DropDownExample = Template.bind({});
// More on  args: https://storybook.js.org/docs/react/writing-stories/args
DropDownExample.args = {
    startIcon:RocketLaunch,
    endIcon:ArrowDownwardSharp,
    width:"20rem",
    iconSize:"lg",
    listItems:[
        <Typography>
            hello
        </Typography>,
        <Typography>
            hello
        </Typography>,
        <Typography>
            hello
        </Typography>,
        <Typography>
            hello
        </Typography>,
        <Typography>
            hello
        </Typography>,
    ]
};