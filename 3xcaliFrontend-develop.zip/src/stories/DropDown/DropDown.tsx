import React from 'react';
import PropTypes from 'prop-types';
import { Accordion, AccordionDetails, AccordionSummary, List, ListItem } from '@mui/material';
import { styled } from '@mui/system';
import { useThemeContext } from '../../theme/theme-context';
import { Label } from '../label/Label';
import { Icon } from '../Icon/Icon';
import { Button } from '../Button/Button';
import { dropDownVariants } from '../Helpers';

export const DropDown:any = ({ variant,headerLabel,startIcon,endIcon,iconSize,buttonLabel,listItems,width,...props }:any) => {

  const { theme } = useThemeContext()

  const dropDownPalette:any = dropDownVariants(variant,theme)
  
  const DropDown = styled(Accordion)(()=>({
      padding:0,
      backgroundColor:dropDownPalette.backgroundColor,
      width:width
  }))

  const DropDownHeader = styled(AccordionSummary)(()=>({
    display:"flex",
    flexDirection:"row",
    justifyContent:"space-between",
    paddingLeft:theme.spacing(2),
    paddingRight:theme.spacing(2),
    width:"100%",
    backgroundColor:dropDownPalette.backgroundColor,
    height:"0",
    "& div:nth-child(1)":{
        margin:theme.spacing(0),
        height:"fit-content",
    },
    borderRadius:theme.shape.borderRadius
  }))

  const DropDownDetails = styled(AccordionDetails)(()=>({
    backgroundColor:dropDownPalette.backgroundColor,
    padding:"0",
    borderRadius:theme.shape.borderRadius
  }))

  const ButtonHolder = styled("div")(()=>({
    padding:theme.spacing(2),
    paddingTop:theme.spacing(1)
  }))

  const DropDownItem = styled(ListItem)(()=>({
    backgroundColor:dropDownPalette.itemBg,
    marginBottom:theme.spacing(1)
  }))

  const DropDownList = styled(List)(()=>({
      padding:0
  }))

  return (
      <DropDown disableGutters elevation={0} className="root-class">
          <DropDownHeader expandIcon={<Icon size={iconSize} color={dropDownPalette.color} Children={endIcon}/>}>
                <Label variant={"h6"} label={headerLabel} starticon={startIcon} iconSize={iconSize} textColor={dropDownPalette.color} iconColor={dropDownPalette.color}/>
          </DropDownHeader>
          <DropDownDetails>
          <DropDownList>
              {
                  listItems && listItems.length>0
                  ?
                  listItems.map((value:any,index:any)=>{
                    return <DropDownItem key={index}>{value}</DropDownItem>
                  })
                  :
                  <></>
              }
          </DropDownList>
          <ButtonHolder>
                <Button
                label={buttonLabel}
                icons={{}}
                fullWidth={true}
                />
          </ButtonHolder>
          </DropDownDetails>
      </DropDown>
  );
};

DropDown.propTypes = {
    headerLabel:PropTypes.string,
    iconSize:PropTypes.string,
    buttonLabel:PropTypes.string,
    variant:PropTypes.string
};

DropDown.defaultProps = {
    headerLabel:"Header",
    iconSize:"md",
    buttonLabel:"Label",
    variant:"default",
    width:"100%"
};