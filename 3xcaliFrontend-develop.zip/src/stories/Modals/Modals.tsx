import * as React from 'react';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import { avatar } from '../../theme/theme-constants/avatar-icon-constants';
import PropTypes from 'prop-types';
import {Label} from '../label/Label'
import { Button } from '../Button/Button';
import { useThemeContext } from '../../theme/theme-context';

export const Modals:any = ({ summary, label,icons, width, iconSize, ...props}:any) => {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  
  const returnIconChild = (iconType:any) => {
    return icons[iconType]!==null?icons[iconType]:null
  }

  const { theme } = useThemeContext()


  const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    boxShadow: 24,
    p: 4,
    backgroundColor: theme.palette.primary.main
  };
  

  return (
    <div>
      <Button onClick={handleOpen}
                label={"buttonLabel"}
                icons={{}}
                fullWidth={true}
                sx={{backgroundColor: theme.palette.primary.dark, height:"0"}}
                >Open Modal</Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"  >
         
        <Box sx={style}>
          <Label starticon = {returnIconChild('startIcon')} iconSize={"sm"} label={"Header"} variant={"body1"} ></Label>

          <Label spacing={2} label={"Modal Headline"} variant={"h4"} 

          endicon={returnIconChild('endIcon')}  ></Label>

          <Label spacing={2} label={"body text for modals"} variant={"body1"}  ></Label>


            <Button
                label={"buttonLabel"}
                icons={{}}
                fullWidth={true}
                style={{backgroundColor: theme.palette.primary.dark, marginTop:"200px" }}
                />

        </Box>
      </Modal>
    </div>
  );
}

Modals.propTypes = {
  summary:PropTypes.string,
  iconSize:PropTypes.any,
  icons: PropTypes.any,
  starticon: PropTypes.any,
  endicon: PropTypes.any
};