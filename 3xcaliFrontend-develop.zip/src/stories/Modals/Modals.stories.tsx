import React from "react";
import CircleIcon from '@mui/icons-material/Circle';
import { Modals } from "./Modals";

export default {
  title: "3six9/Modals",
  component: Modals,
};
const Template:any = (args:any) => <Modals {...args} />;
export const ModalComponent = Template.bind({});
ModalComponent.args = {
  summary:
    "body text for Accordions",
  iconSize:"sm",
  icons:{ startIcon: CircleIcon , expandIcon: CircleIcon  },
  startIcon:CircleIcon,
  endIcon:CircleIcon,
  width:"20rem"};
