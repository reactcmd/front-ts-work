import { RocketLaunch } from '@mui/icons-material';
import React from 'react';

import { Label } from './Label';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: '3six9/Labels',
  component: Label,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {
    backgroundColor: { control: 'color' },
  },
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template:any = (args:any) => <Label {...args} />;

export const TextLabel = Template.bind({});
// More on  args: https://storybook.js.org/docs/react/writing-stories/args
TextLabel.args = {
    starticon: null,
    endicon: null,
    label:  'Label',
    spacing:0.5
};

export const LeftIconLabel = Template.bind({});

LeftIconLabel.args = {
  starticon: RocketLaunch,
  endicon: null,
  label:  'Label',
  spacing:0.5
};

export const RightIconLabel = Template.bind({});

RightIconLabel.args = {
  starticon: null,
  endicon: RocketLaunch,
  label:  'Label',
  spacing:0.5
};

export const DoubleHorizontalLabel = Template.bind({});

DoubleHorizontalLabel.args = {
  starticon: RocketLaunch,
  endicon: RocketLaunch,
  label:  'Label',
  spacing:0.5
};

export const NoTextLabel = Template.bind({});

NoTextLabel.args = {
  starticon: RocketLaunch,
  label:  '',
  spacing:0.5
};

export const TopIconLabel = Template.bind({});

TopIconLabel.args = {
  starticon: RocketLaunch,
  endicon: null,
  label:  'Label',
  spacing:0.5,
  gridDirection:"column"
};

export const BottomIconLabel = Template.bind({});

BottomIconLabel.args = {
  starticon: null,
  endicon: RocketLaunch,
  label:  'Label',
  spacing:0.5,
  gridDirection:"column"
};

export const DoubleVerticalLabel = Template.bind({});

DoubleVerticalLabel.args = {
  starticon: RocketLaunch,
  endicon: RocketLaunch,
  label:  'Label',
  spacing:0.5,
  gridDirection:"column"
};

