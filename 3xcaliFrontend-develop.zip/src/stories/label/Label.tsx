import React from 'react';
import PropTypes from 'prop-types';
import { Grid, styled } from '@mui/material';
import Typography from '@mui/material/Typography';
import { useThemeContext } from '../../theme/theme-context';
import { Icon } from '../Icon/Icon';

export const Label:any = ({ starticon,endicon, label,variant,spacing,textColor,iconColor,iconSize,gridDirection, ...props }:any) => {

  const { theme } = useThemeContext()

  const LabelText = styled(Typography)(()=>({
      fontSize:theme.typography[variant].fontSize,
      color:textColor?textColor:theme.palette.primary.contrastText,
      fontWeight:theme.typography[variant].fontWeight,
  }))

  const FirstIcon = styled(starticon?starticon:"div")(()=>({
    color:iconColor
  }))

  const LastIcon = styled(endicon?endicon:"div")(()=>({
    color:iconColor
  }))

  return (
    <Grid container direction={gridDirection} alignItems="center" columnSpacing={theme.spacing(spacing)} style={{width:"max-content"}}>
        <Grid item>
          {
            starticon?
              <Icon size={iconSize} Children={FirstIcon}></Icon>
            :
              <></>
          }
        </Grid>
        <Grid item>
            {
                label?
                <LabelText >
                    {label}
                </LabelText>
                :
                <></>
            }

        </Grid>
        <Grid item>
          {
            endicon?
              <Icon size={iconSize} Children={LastIcon}></Icon>
            :
            <></>
          }
        </Grid>
  </Grid>
  );
};

Label.propTypes = {
  starticon: PropTypes.any,
  endicon: PropTypes.any,
  label:  PropTypes.string,
  variant:PropTypes.string,
  spacing:PropTypes.number,
  textColor:PropTypes.string,
  iconColor:PropTypes.string,
  iconSize:PropTypes.string,
  gridDirection:PropTypes.string
};

Label.defaultProps = {
    starticon: null,
    endicon: null,
    variant:'h5',
    spacing:0.5,
    color:"null",
    iconSize:"lg",
    gridDirection:"row"
};