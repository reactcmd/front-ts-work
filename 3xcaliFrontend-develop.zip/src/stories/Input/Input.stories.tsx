import { RocketLaunch } from '@mui/icons-material';
import React from 'react';

import { Input } from './Input';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: '3six9/Input',
  component: Input,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {
    backgroundColor: { control: 'color' },
  },
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template:any = (args:Record<string,any>) =><Input {...args} />;

export const InputComponent = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
InputComponent.args = {
    startIcon:RocketLaunch,
    endIcon:RocketLaunch,
    validationFunction:(value:any)=>{
      return value==="1234"
    },
    action:{
      label:"lel",
      actionCallback:()=>{console.log("hey")},
      icon:RocketLaunch
    },
    placeholder:"Enter some text"
};
