import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { styled,InputBase, FormHelperText } from '@mui/material';
import { useThemeContext } from '../../theme/theme-context';
import { Box } from '@mui/system';
import { Button } from '../Button/Button';
import { inputVariants } from '../Helpers';

export const Input = ({ startIcon,label,action,placeholder,variant,validationFunction,errorCallback,errorMessage,inputRef,...props }:any) => {

  const { theme } = useThemeContext()

  const [focused,setFocused] = useState(false);

  const [error,setError] = useState(false);

  const [value,setValue] = useState("");
  
  const inputPalette:any = inputVariants(variant,theme)

  const InputBox = styled(Box)(()=>({
    backgroundColor:inputPalette.backgroundColor,
    borderRadius: theme.shape.borderRadius,
    padding:theme.spacing(2),
    display: 'flex',
    alignItems: 'center',
    width: `calc(100% - ${theme.spacing(4)})`,
    position:"relative",
    "& *":{
      color:returnCurrentInputColor()
    },
    border:`${theme.spacing(0.25)} ${returnCurrentInputBorderColor()} solid`
  }))

  const returnCurrentInputColor = () =>{
      if(error){
          return inputPalette.textColorOther
      }
      else if(focused){
        return inputPalette.textColorOther
      }
      else{
        return inputPalette.textColorNormal
      }
  }

  const returnCurrentInputBorderColor = () =>{
      if(error){
          return inputPalette.borderColorError
      }
      else if(focused){
        return inputPalette.borderColorSelected
      }
      else{
        return inputPalette.borderColorNormal
      }
  }

  const changeFocus = (bool:any) =>{
    if(focused!==bool){
        setFocused(bool)
    }
  }

  const runValidationFunction = (event:any) =>{
      setValue(event.target.value)
      if(inputRef){
        inputRef.current = event.target.value
      }
      let errorState = !validationFunction(event.target.value)
      setError(errorState)
      errorCallback(errorState)
  }

  return (
      <Box sx={{width:"100%"}}>
        <InputBox>
            <Button colorOverride={returnCurrentInputColor()} icons={{startIcon:startIcon}} buttonType="unstyled" />
            <InputBase value={value} autoFocus={focused} onFocus={()=>changeFocus(true)} onBlur={()=>changeFocus(false)} onChange={runValidationFunction}
                sx={{ ml: 1, flex: 1 }}
                placeholder={placeholder}
            />
            {
              (action!==null)?
              <Button colorOverride={returnCurrentInputColor()} label={action.label} icons={{endIcon:action.icon}} buttonType="unstyled" onClick={action.actionCallback} />
              :
              <></>
            }
        </InputBox>
        {
            error?
            <FormHelperText sx={{color:inputPalette.borderColorError}}>
                {errorMessage}
            </FormHelperText>
            :
            <></>
        }
      </Box>
  );
};

Input.propTypes = {
    startIcon:PropTypes.any,
    label:PropTypes.string
};

Input.defaultProps = {
    startIcon:null,
    label:'label',
    placeholder:"Form Input",
    variant:"default",
    validationFunction:(e:any)=>true,
    errorCallback:(e:any)=>true,
    errorMessage:"Incorrect entry."
};