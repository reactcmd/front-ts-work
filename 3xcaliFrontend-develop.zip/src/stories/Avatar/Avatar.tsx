import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { Avatar as UserAvatar } from '@mui/material';
import { useThemeContext } from '../../theme/theme-context';
import { avatar } from '../../theme/theme-constants/avatar-icon-constants';

export const Avatar:any = ({ size,image,alt,children,...props }:any) => {

  const { theme } = useThemeContext()

  useEffect(()=>{
      console.log(avatar)
  })

  return (
    <UserAvatar sx={{ width: `${avatar[size]}px`, height: `${avatar[size]}px` }} alt={alt} src={image}>{children}</UserAvatar>
  );
};

Avatar.propTypes = {
    size:PropTypes.string,
    image:PropTypes.any,
    alt:PropTypes.string,
    children:PropTypes.any
};

Avatar.defaultProps = {
    size:'sm',
    image:"",
    alt:"",
    children:null
};