import React from 'react';

import { Avatar } from './Avatar';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: '3six9/Avatar',
  component: Avatar,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {
    backgroundColor: { control: 'color' },
  },
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template:any = (args:Record<string,any>) => <Avatar {...args} />;

export const AvatarXS = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
AvatarXS.args = {
    size:"xs"
};

export const AvatarS = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
AvatarS.args = {
    size:"sm"
};

export const AvatarM = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
AvatarM.args = {
    size:"md"
};

export const AvatarL = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
AvatarL.args = {
    size:"lg"
};

export const AvatarXL = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
AvatarXL.args = {
    size:"xl"
};

export const AvatarXXL = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
AvatarXXL.args = {
    size:"xxl"
};

export const Avatar3XL = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Avatar3XL.args = {
    size:"3xl"
};

export const Avatar4XL = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Avatar4XL.args = {
    size:"4xl"
};

export const Avatar5XL = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Avatar5XL.args = {
    size:"5xl"
};

export const Avatar7XL = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Avatar7XL.args = {
    size:"7xl"
};

