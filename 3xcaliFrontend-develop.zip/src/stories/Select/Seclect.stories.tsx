import React from "react";
import CircleIcon from '@mui/icons-material/Circle';

import {SelectMUI} from "./Select";

export default {
  title: "3six9/Select",
  component: SelectMUI,
  argTypes: {
    backgroundColor: { control: 'color' },
  },
};
const Template:any = (args:any) => <SelectMUI {...args} />;
export const SelectComponent = Template.bind({});
SelectComponent.args = {
  startIcon:CircleIcon,
  endIcon:CircleIcon,
  validationFunction:(value:any)=>{
    return value==="1234"
  },
  disable: true,
}