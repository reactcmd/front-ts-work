import React, { useState } from 'react';
import Box from '@mui/material/Box';
import { useThemeContext } from '../../theme/theme-context';
import { Label } from '../label/Label';
import PropTypes from 'prop-types';
import { styled,InputBase, FormHelperText } from '@mui/material';
import { inputVariants } from '../Helpers';
import { Button } from '../Button/Button';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import {  makeStyles } from '@mui/styles';


export const SelectMUI:any = ({ startIcon,endIcon,label,action,placeholder,variant,disabled,validationFunction,errorCallback,errorMessage,inputRef,...props }:any) => {

    const { theme } = useThemeContext()
  
    const [focused,setFocused] = useState(false);
  
    const [error,setError] = useState(false);
  
    const [value,setValue] = useState("");
    
    const inputPalette:any = inputVariants(variant,theme)
    


    const InputBox = styled(Box)(()=>({
      backgroundColor:inputPalette.backgroundColor,
      borderRadius: theme.shape.borderRadius,
      padding:theme.spacing(2),
      display: 'flex',
      alignItems: 'center',
      width: `calc(100% - ${theme.spacing(4)})`,
      position:"relative",
      "& *":{
        color:returnCurrentInputColor()
      },
      border:`${theme.spacing(0.25)} ${returnCurrentInputBorderColor()} solid`
    }))
  
    const returnCurrentInputColor = () =>{
        if(error){
            return inputPalette.textColorOther
        }
        else if(focused){
          return inputPalette.textColorOther
        }
        else{
          return inputPalette.textColorNormal
        }
    }
  
    const returnCurrentInputBorderColor = () =>{
        if(error){
            return inputPalette.borderColorError
        }
        else if(focused){
          return inputPalette.borderColorSelected
        }
        else{
          return inputPalette.borderColorNormal
        }
    }
  
    const changeFocus = (bool:any) =>{
      if(focused!==bool){
          setFocused(bool)
      }
    }
  
    const runValidationFunction = (event:any) =>{
        setValue(event.target.value)
        if(inputRef){
          inputRef.current = event.target.value
        }
        let errorState = !validationFunction(event.target.value)
        setError(errorState)
        errorCallback(errorState)
    }

    const [age, setAge] = React.useState('');
    const handleChange = (event:any) => {
        setAge(event.target.value);
      };
      

    const useStyles = makeStyles({
        labella: {
          color: "white",
          "&.Mui-focused": {
            color: "white",
          },
        },
      });

    const classes:any = useStyles();

    const CustomBox:any = styled(Box)(()=>({}));
    const CustomFormControl:any = styled(FormControl)(()=>({}));
    const CustomSelect:any = styled(Select)(()=>({}));
    const CustomMenuItem:any = styled(Select)(()=>({}));
    const CustomInputBox:any = styled(InputBox)(()=>({}));

    return (
        <CustomBox sx={{ width:"100%" ,alignItems: 'flex-end' }} disabled = {disabled}>

        
        
          <CustomInputBox fullWidth={true}>

          <Label  align="center" label={"Label"} variant={"h6"} />              
          <Button colorOverride={returnCurrentInputColor()} icons={{startIcon:startIcon}} buttonType="unstyled" />
              <InputBase value={value} autoFocus={focused} onFocus={()=>changeFocus(true)} onBlur={()=>changeFocus(false)} onChange={runValidationFunction}
                  sx={{ ml: 1, flex: 1 }}
                  placeholder={placeholder}
              />
               <CustomFormControl sx={{ alignItems: 'flex-end' }}>
                    <CustomSelect 
                            classes={{ root: classes.labella }}
                            sx={{color:"white !important",  }}
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={age}
                            onChange={handleChange}
                            >
                            <CustomMenuItem classes={classes.label}value={10}>Value1</CustomMenuItem>
                            <CustomMenuItem classes={classes.label} value={20}>Value2</CustomMenuItem>
                            <CustomMenuItem classes={classes.label} value={30}>Value3</CustomMenuItem>
                    </CustomSelect>
                </CustomFormControl>
              
          </CustomInputBox>
          {
              error?
              <FormHelperText sx={{color:inputPalette.borderColorError}}>
                  {errorMessage}
              </FormHelperText>
              :
              <></>
          }
        </CustomBox>
    );
  };


  SelectMUI.propTypes = {
    startIcon:PropTypes.any,
    label:PropTypes.string
};

SelectMUI.defaultProps = {
    startIcon:null,
    label:'label',
    placeholder:"Form Input",
    variant:"default",
    validationFunction:(e:any)=>true,
    errorCallback:(e:any)=>true,
    errorMessage:"Incorrect entry."
};