export const borderRadius:Record<string,number> = {
    "radius-s": 4,
    "radius-xs": 2,
    "radius-m": 8,
    "radius-l": 16,
    "radius-xl": 32,
}

export const avatar:Record<string,number> = {
      "xs":12,
      "sm":16,
      "md":20,
      "lg":24,
      "xl":28,
      "xxl":32,
      "3xl":36,
      "4xl":40,
      "5xl":80,
      "7xl":88
}

export const icon:Record<string,number> = {
        "xs":12,
        "sm":16,
        "md":20,
        "lg":24,
        "xl":32,
        "xxl":40,
        "3xl":48,
        "4xl":72,
        "5xl":160,
        "7xl":320
}