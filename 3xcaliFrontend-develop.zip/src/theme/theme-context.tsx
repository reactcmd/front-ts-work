import React, { useState, useContext, useMemo, createContext, useEffect } from "react";
import { ThemeProvider as MUIThemeProvider } from "@mui/material/styles";
import { ThemeProvider } from '@emotion/react'
import { themeMap } from "./theme-templates";
import addons from '@storybook/addons';

const channel = addons.getChannel();

const getThemeByName = (theme:string) => {
  return themeMap[theme];
}

export const ThemeContextCustom:React.Context<any> = createContext(null);

export const useThemeContext = () => {
    const themeContext:any = useContext(ThemeContextCustom);
    const { themeProvider } = themeContext;
    return useMemo(() => {
        return { ...themeProvider };
    }, [themeContext]);
};

export const ThemeContextProvider = ({ children }:any) => {

    const [themeType,setThemeType] = useState('lightTheme')

    const theme = useMemo(()=>{
        return getThemeByName(themeType)
    },[themeType]);

    const themeProvider = useMemo(
        () => ({
            theme,
            themeType,
            setThemeType
        }),
        [theme,themeType,setThemeType],
    );

    const setDark = (isDark:string) =>{
        let theme = isDark?'darkTheme':'lightTheme'
        console.log(theme)
        setThemeType(theme)
    }

    useEffect(() => {
      channel.on('DARK_MODE',setDark);
      return () => channel.off('DARK_MODE', setDark);
    }, [channel, setDark]);
    
    return(
        <MUIThemeProvider theme={theme}>
          <ThemeProvider theme={theme}>
              <ThemeContextCustom.Provider value={{ themeProvider }}>{children}</ThemeContextCustom.Provider>
          </ThemeProvider>
        </MUIThemeProvider>
    )
};
