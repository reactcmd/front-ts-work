export const dark:any = {
  "palette": {
    "mode": "dark",
    "primary": {
        "10":"#F7FBFF",
        "20": "#f0efff",
        "30": "#C7D9FF",
        "50": "#c1c0ff",
        "70": "#9d9eff",
        "90": "#767fff",
        "300": "#4558ff",
        "700": "#001eff",
        "800": "#00188b",
        "900": "#000411",
        "main": "#c1c0ff",
        "light": "#f0efff",
        "dark": "#00188b",
        "contrastText": "rgba(255, 255, 255, 0.87)"
    },
    "divider": "#ffffff",
    "background": {
        "default": "#001E3C",
        "paper": "#0A1929"
    },
    "common": {
        "black": "#1D1D1D",
        "white": "#ffffff"
    },
    "text": {
        "primary": "#ffffff",
        "secondary": "#B2BAC2",
        "disabled": "rgba(255, 255, 255, 0.5)",
        "icon": "rgba(255, 255, 255, 0.5)",
        "button":"#00188b",
        "typography":"#ffffff"
    },
    "grey": {
        "50": "#F3F6F9",
        "100": "#E7EBF0",
        "200": "#E0E3E7",
        "300": "#CDD2D7",
        "400": "#B2BAC2",
        "500": "#A0AAB4",
        "600": "#6F7E8C",
        "700": "#3E5060",
        "800": "#2D3843",
        "900": "#1A2027",
        "A100": "#f5f5f5",
        "A200": "#eeeeee",
        "A400": "#bdbdbd",
        "A700": "#616161"
    },
    "error": {
        "50": "#FFF0F1",
        "100": "#FFDBDE",
        "200": "#FFBDC2",
        "300": "#FF99A2",
        "400": "#FF7A86",
        "500": "#FF505F",
        "600": "#EB0014",
        "700": "#C70011",
        "800": "#94000D",
        "900": "#570007",
        "main": "#EB0014",
        "light": "#FF99A2",
        "dark": "#C70011",
        "contrastText": "#fff"
    },
    "success": {
        "50": "#E9FBF0",
        "100": "#C6F6D9",
        "200": "#9AEFBC",
        "300": "#6AE79C",
        "400": "#3EE07F",
        "500": "#21CC66",
        "600": "#1DB45A",
        "700": "#1AA251",
        "800": "#178D46",
        "900": "#0F5C2E",
        "main": "#1DB45A",
        "light": "#6AE79C",
        "dark": "#1AA251",
        "contrastText": "rgba(0, 0, 0, 0.87)"
    },
    "warning": {
        "50": "#FFF9EB",
        "100": "#FFF3C1",
        "200": "#FFECA1",
        "300": "#FFDC48",
        "400": "#F4C000",
        "500": "#DEA500",
        "600": "#D18E00",
        "700": "#AB6800",
        "800": "#8C5800",
        "900": "#5A3600",
        "main": "#DEA500",
        "light": "#FFDC48",
        "dark": "#AB6800",
        "contrastText": "rgba(0, 0, 0, 0.87)"
    },
    "secondary": {
        "20":"#fce0ff",
        "50":"#f5aaff",
        "70":"#e786ff",
        "100":"#cf56ff",
        "600":"#b000ff",
        "700":"#7e00c6",
        "800":"#39006a",
        "900":"#18003c",
        "main": "#cf56ff",
        "light": "#f5aaff",
        "dark": "#39006a",
        "contrastText": "rgba(0, 0, 0, 0.87)"
    },
    "info": {
        "main": "#29b6f6",
        "light": "#4fc3f7",
        "dark": "#0288d1",
        "contrastText": "rgba(0, 0, 0, 0.87)"
    },
    "contrastThreshold": 3,
    "tonalOffset": 0.2,
    "action": {
        "active": "#cf56ff",
        "hover": "rgba(255, 255, 255, 0.08)",
        "hoverOpacity": 0.08,
        "selected": "#cf56ff",
        "selectedOpacity": 0.16,
        "disabled": "rgba(255, 255, 255, 0.3)",
        "disabledBackground": "rgba(255, 255, 255, 0.12)",
        "disabledOpacity": 0.38,
        "focus": "#cf56ff",
        "focusOpacity": 0.12,
        "activatedOpacity": 0.24
    }
},
  "typography": {
    "h1": {
        "color":"#ffffff"
    },
    "h2": {
        "color":"#ffffff"
    },
    "h3": {
        "color":"#ffffff"
    },
    "h4": {
        "color":"#ffffff"
    },
    "h5": {
        "color":"#ffffff"
    },
    "h6": {
        "color":"#ffffff"
    },
    "button": {
        "color":"#ffffff"
    },
    "subtitle1": {
        "color":"#ffffff"
    },
    "body1": {
        "color":"#ffffff"
    },
    "body2": {
        "color":"#ffffff"
    },
    "caption": {
        "color":"#ffffff"
    },
    "subtitle2": {
        "color":"#ffffff"
    },
    "overline": {
        "color":"#ffffff"
    }
  },
  "nprogress": {
      "color": "#007FFF"
  },
}