import { light } from "./light";
import { dark } from "./dark";
import { baseTheme } from "./baseTheme";
import {
  createTheme
} from "@mui/material/styles";


const lightTheme:Record<string,any> = createTheme({...baseTheme,...light})
const darkTheme:Record<string,any> = createTheme({...baseTheme,...dark})

export const themeMap:Record<string,Record<string,any>> = {
    lightTheme:lightTheme,
    darkTheme:darkTheme,
}